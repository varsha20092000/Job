module.exports = {
  content: [
    './App/templates/**/*.html',
    './App/static/js/**/*.js'
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
